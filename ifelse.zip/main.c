/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int number;
    printf("Enter an integer:");
    scanf("%d",&number);
    if(number<0)
    {
        printf("you entered %d\n",number);
        number = number+10;
        printf("%d \n",number);
    }
    
    else
    {
        printf(" you are in else part now \n");
    }
    printf("%d",number);
    

    return 0;
}
