/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n;
    char name[20];
    float amt;
    printf("name = \n");
    scanf("%s", name);
    printf("units\n");
    scanf("%d",&n);
    if (n<=200)
    {
        amt = n*80;
    }
    else if (n>200&&n<=300)
    {
        amt = 200*80;
        amt = amt + (n - 200)*90;
        
    }
    
    else
    {
        amt = (n - 300)*100;
        amt = 100*90;
        amt = 200*80;
    }
    amt= amt/100;
    amt = amt + 100;
    
    if (amt>400)
    {
        amt = amt + 15*amt/100;
        
    }
printf("amount: %f",amt);
    return 0;
}
