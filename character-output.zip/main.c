/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   int a,b,c,x,y,z;
   int p,q,r;
   printf("enter three integer numbers ");
   scanf("%d %*d %d",&a ,&b,&c);
   printf("%d %d %d\n\n ",a ,b ,c);
   
   printf("two 4-digit numbers\n");
   scanf("%2d %4d ", &x ,&y);
   printf("%d %d \n \n",x ,y);
   
   printf("enter two integers \n");
   scanf("%d %d",&a,&x);
   printf("%d %d \n \n",a ,x);
   
   printf("enter  nine digit integers\n");
   scanf("%3d %4d %3d", &p ,&q, &r);
   printf("%d %d %d \n\n",p,q,r);
   
   printf("enter two three digit numbers \n ");
   scanf("%d %d",&x,&y);
   printf("%d %d",x,y);
   
  
   
   
   
   
   
    return 0;
}
