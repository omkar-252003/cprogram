/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#define MAX 4
void main()
{
  int m,x,binom;
  printf("out  m x");
  
  for(m=0;m<=MAX;++m);
    
        printf("%4d",m);
        
    
  printf("\n ------------------------------------------------\n");
  m=0;
  do
  {
      printf("%2d",m);
      x=0;binom = 1;
      
      while(x<=m)
      {
          if (m == 0||x == 0)
          printf("%4d",binom);
          
          else
          {
            binom = binom *( m-x +1)/x;
            printf("%4d", binom);
          }
      x = x+1;
      
      }
      
      printf("\n");
      m = m+1;
      
  }
    while ( m<= MAX);
    printf("-------------------------------------------------------\n");

    
}


