/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<ctype.h>
int main()
{
    char character;
    printf("press any key \n");
    character =getchar();
    if (isalpha (character)>0 )
    printf("its a letter");
    
    
    else 
    if (isdigit(character)>0)
    printf("its a digit");
    
    else
        printf("the character isn't alphanumeric");
        
        
    

    return 0;
}
