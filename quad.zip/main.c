/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<math.h>
int main()
{
    float a ,b ,c,disc;
    float root1,root2,real,img;
    printf("enter a,b,c values \n");
    scanf("%f %f %f",&a,&b,&c);
    if ((a==0) && (b==0))
    {
        printf("invalid co-eff \n");
        printf("try again with valid inputs !!!\n");
    }
    
    else if (a == 0)
              {
                  printf("linear equation \n");
                  
                   root1 = -c/b ;
                   printf( "Root = %.3f",root1);
                   
                  
              }
    else
    {
        disc = b*b -4*a*c;
        if (disc ==0)
        {
            printf("roots are real and equal\n");
            root1 = root2 = -b/(2*a);
            printf("Root1 = %.3f \n Root2 = %.3f",root1,root2);
            
            
        }
        
        else if(disc>0)
        {
            printf("The roots are real and distinct \n");
            root1 = (-b + sqrt(disc))/(2*a);
            root2 = (-b - sqrt(disc))/(2*a);
            printf("Root1 = %.3f \n Root2 = %.3f",root1,root2);
            
        }
        
        else
        {
            printf("The roots are real and imaginary\n ");
            real = -b/(2*a);
            
            img = sqrt(fabs(disc))/(2*a);
            printf("Root1 = %.3f +i %.3f \n", real, img);
            printf("Root2 = %.3f -i %.3f \n",real, img);
        }
    }
           
   

    return 0;
}
