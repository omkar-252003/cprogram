/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int g = 500;
    float f = 3.1456;
    printf("1. %d \n",g);
    printf("2. %7d\n",g);
    printf("3. %-4d\n",g);
    printf("4. %03d\n",g);
    
    printf("5. %6.3f\n",f);
    printf("6. %-7.2f\n",f);
    printf("7. %f\n",f);
    printf("8. %8.1e\n",f);
    printf("9.%8.2e\n",-f);
    printf("10.%-5.4e\n",f);
    
    char a = "god" ;
    
    printf("11. %2c\n",a);
    
    char str[10] = "bitcoin";
    
    printf("12. %15.8s\n",str);
    

    return 0;
}

